from . import flashcards

__all__ = ["flashcards"]